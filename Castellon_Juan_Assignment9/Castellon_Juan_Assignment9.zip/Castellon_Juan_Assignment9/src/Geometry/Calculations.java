/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Geometry;

/**
 *
 * @author Juan
 */
public interface Calculations {
    public abstract void setLen(double x);
    public abstract void setPer();
    public abstract void setAre();
    public abstract void prompt();
    public abstract void toStri();
}
